$(document).ready(function() {

$(".nav-sidebar ul li a").click(function() {
      	$(".nav-sidebar ul li").removeClass('selected');
        $(this).parent().addClass('selected');
	});

});